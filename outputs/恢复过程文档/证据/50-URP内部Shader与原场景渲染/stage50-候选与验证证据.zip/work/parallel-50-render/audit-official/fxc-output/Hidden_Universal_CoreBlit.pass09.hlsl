

        #pragma target 2.0
        #pragma editor_sync_compilation
        #pragma multi_compile _ DISABLE_TEXTURE2D_X_ARRAY
        #pragma multi_compile _ BLIT_SINGLE_SLICE
        // Core.hlsl for XR dependencies
#include "C:/Users/luxinyu/Documents/Codex/2026-10-19/x20/work/parallel-50-render/audit-official/fxc-output/includes/d1e314049aaa7d73_Core.hlsl"
#include "C:/Users/luxinyu/Documents/Codex/2026-10-19/x20/work/parallel-50-render/audit-official/fxc-output/includes/eea97f074146e052_Blit.hlsl"
        // DebuggingFullscreen.hlsl for URP debug draw
#include "C:/Users/luxinyu/Documents/Codex/2026-10-19/x20/work/parallel-50-render/audit-official/fxc-output/includes/75863dae757182a1_DebuggingFullscreen.hlsl"
        // Color.hlsl for color space conversion
#include "C:/Users/luxinyu/Documents/Codex/2026-10-19/x20/work/parallel-50-render/audit-official/fxc-output/includes/019f417615a1a62f_Color.hlsl"

        // Specialized blit with URP debug draw support and color space conversion support
        // Keep in sync with BlitHDROverlay.shader
        half4 FragmentURPBlit(Varyings input, SamplerState blitsampler)
        {
            half4 color = FragBlit(input, blitsampler);

            #ifdef _LINEAR_TO_SRGB_CONVERSION
            color = LinearToSRGB(color);
            #endif

            #if defined(DEBUG_DISPLAY)
            half4 debugColor = 0;
            float2 uv = input.texcoord;
            if (CanDebugOverrideOutputColor(color, uv, debugColor))
            {
                return debugColor;
            }
            #endif

            return color;
        }
    

                #pragma vertex VertQuadPadding
                #pragma fragment FragNearest
                #define WITH_ALPHA_BLEND
            