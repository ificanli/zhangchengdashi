

        #pragma target 2.0
        #pragma editor_sync_compilation
        #pragma multi_compile _ DISABLE_TEXTURE2D_X_ARRAY
        #pragma multi_compile _ BLIT_SINGLE_SLICE
        // Core.hlsl for XR dependencies
#include "C:/Users/luxinyu/Documents/Codex/2026-10-19/x20/work/parallel-50-render/audit-official/fxc-output/includes/d1e314049aaa7d73_Core.hlsl"
#include "C:/Users/luxinyu/Documents/Codex/2026-10-19/x20/work/parallel-50-render/audit-official/fxc-output/includes/7c65ec6395a9d592_BlitColorAndDepth.hlsl"
    

                #pragma vertex Vert
                #pragma fragment FragColorOnly
            